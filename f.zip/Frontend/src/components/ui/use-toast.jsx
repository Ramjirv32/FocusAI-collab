// Create this file if it doesn't exist
import { useToast } from "./toast";

export { useToast, toast } from "./toast";