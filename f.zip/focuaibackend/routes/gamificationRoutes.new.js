const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Gamification = require('../models/Gamification');
const UserProfile = require('../models/UserProfile');
const ProductivitySummary = require('../models/ProductivitySummary');

/**
 * @route   GET /api/gamification/stats
 * @desc    Get user's gamification stats
 * @access  Private
 */
router.get('/stats', auth, async (req, res) => {
  try {
    const userId = req.user._id; // Use _id from the user document
    const email = req.user.email; // Get email from the user document
    
    // Find the user's gamification data
    let gamificationData = await Gamification.findOne({ userId });
    
    // If no gamification data exists, create a new one
    if (!gamificationData) {
      gamificationData = new Gamification({
        userId,
        email, // Include the email field
        points: {
          total: 0,
          daily: 0,
          weekly: 0,
          monthly: 0
        },
        level: {
          current: 1,
          progress: 0,
          nextLevelAt: 1000
        },
        badges: [],
        challenges: [],
        streaks: {
          current: 0,
          longest: 0,
          lastActiveDate: new Date()
        },
        statistics: {
          totalFocusTime: 0,
          totalProductiveTime: 0,
          totalDistractionTime: 0,
          averageFocusScore: 0,
          sessionsCompleted: 0
        }
      });
      await gamificationData.save();
    }
    
    // Format the data for frontend
    const nextLevelPoints = calculateNextLevelPoints(gamificationData.level.current);
    const currentLevelPoints = calculateNextLevelPoints(gamificationData.level.current - 1);
    const pointsNeeded = nextLevelPoints - currentLevelPoints;
    
    const stats = {
      level: gamificationData.level.current,
      points: gamificationData.points.total,
      pointsToNextLevel: nextLevelPoints - gamificationData.points.total,
      totalPointsForLevel: pointsNeeded,
      badgeCount: gamificationData.badges.length,
      achievements: {
        total: gamificationData.challenges.length + gamificationData.badges.length,
        completed: gamificationData.challenges.filter(c => c.completed).length + gamificationData.badges.length,
      },
      challenges: {
        total: gamificationData.challenges.length,
        completed: gamificationData.challenges.filter(c => c.completed).length,
        active: gamificationData.challenges.filter(c => !c.completed && (!c.expiryDate || new Date(c.expiryDate) > new Date())).length,
      },
      streak: {
        current: gamificationData.streaks.current,
        longest: gamificationData.streaks.longest,
      },
      badges: {
        bronze: gamificationData.badges.filter(b => b.rarity === 'bronze').length,
        silver: gamificationData.badges.filter(b => b.rarity === 'silver').length,
        gold: gamificationData.badges.filter(b => b.rarity === 'gold').length,
        platinum: gamificationData.badges.filter(b => b.rarity === 'platinum').length,
        diamond: gamificationData.badges.filter(b => b.rarity === 'diamond').length,
        master: gamificationData.badges.filter(b => b.rarity === 'master').length,
        legendary: gamificationData.badges.filter(b => b.rarity === 'legendary').length,
      },
      nextLevelPoints: nextLevelPoints,
      progressToNextLevel: calculateProgressPercentage(gamificationData.points.total, gamificationData.level.current)
    };
    
    res.json({ success: true, stats });
  } catch (error) {
    console.error('Error fetching gamification stats:', error);
    res.status(500).json({ success: false, error: 'Server error' });
  }
});

/**
 * @route   GET /api/gamification/achievements
 * @desc    Get user's achievements
 * @access  Private
 */
router.get('/achievements', auth, async (req, res) => {
  try {
    const userId = req.user._id;
    
    // Find the user's gamification data
    const gamificationData = await Gamification.findOne({ userId });
    
    if (!gamificationData) {
      return res.json({ success: true, achievements: [] });
    }
    
    // Map challenges to achievements format for frontend
    const achievements = gamificationData.challenges
      .filter(challenge => challenge.completed)
      .map(challenge => ({
        id: challenge.challengeId,
        name: challenge.name,
        description: challenge.description,
        completed: challenge.completed,
        progress: challenge.progress,
        maxProgress: challenge.target,
        dateCompleted: challenge.completedAt,
        pointsAwarded: challenge.reward,
        claimed: challenge.claimed || false,
        category: challenge.category || 'focus',
        icon: challenge.icon || 'trophy',
        type: determineBadgeType(challenge.reward) // Helper function to determine badge type
      }));
    
    // Add badges as achievements too
    const badgeAchievements = gamificationData.badges.map(badge => ({
      id: badge.badgeId,
      name: badge.name,
      description: badge.description,
      completed: true,
      progress: 100,
      maxProgress: 100,
      dateCompleted: badge.earnedDate,
      pointsAwarded: 0, // Badges don't have points in this model
      claimed: true, // Badges are automatically claimed
      category: badge.category || 'badge',
      icon: badge.icon || 'award',
      type: badge.rarity || 'bronze'
    }));
    
    res.json({ success: true, achievements: [...achievements, ...badgeAchievements] });
  } catch (error) {
    console.error('Error fetching achievements:', error);
    res.status(500).json({ success: false, error: 'Server error' });
  }
});

/**
 * @route   GET /api/gamification/challenges
 * @desc    Get user's active challenges
 * @access  Private
 */
router.get('/challenges', auth, async (req, res) => {
  try {
    const userId = req.user._id;
    
    // Find the user's gamification data
    const gamificationData = await Gamification.findOne({ userId });
    
    if (!gamificationData) {
      return res.json({ success: true, challenges: [] });
    }
    
    // Format challenges for frontend
    const challenges = gamificationData.challenges.map(challenge => ({
      id: challenge.challengeId,
      name: challenge.name,
      description: challenge.description,
      progress: challenge.progress,
      target: challenge.target,
      deadline: challenge.expiryDate,
      pointsAwarded: challenge.reward,
      completed: challenge.completed,
      completedAt: challenge.completedAt,
      category: challenge.category || 'focus',
      isActive: !challenge.completed && (!challenge.expiryDate || new Date(challenge.expiryDate) > new Date()),
      status: challenge.completed ? 'completed' : 
              (challenge.expiryDate && new Date(challenge.expiryDate) < new Date() ? 'expired' : 'active'),
      icon: challenge.icon || 'flag',
      type: determineBadgeType(challenge.reward) // Helper function to determine badge type
    }));
    
    res.json({ success: true, challenges });
  } catch (error) {
    console.error('Error fetching challenges:', error);
    res.status(500).json({ success: false, error: 'Server error' });
  }
});

/**
 * @route   GET /api/gamification/leaderboard
 * @desc    Get leaderboard data
 * @access  Private
 */
router.get('/leaderboard', auth, async (req, res) => {
  try {
    // Get top 10 users by points
    const topUsers = await Gamification.find()
      .sort({ 'points.total': -1, 'streaks.current': -1 })
      .limit(10)
      .lean();
    
    // Get user profiles to add names
    const userIds = topUsers.map(user => user.userId);
    const userProfiles = await UserProfile.find({ userId: { $in: userIds } })
      .select('userId name avatar')
      .lean();
    
    // Map to create a lookup table
    const profileMap = {};
    userProfiles.forEach(profile => {
      profileMap[profile.userId.toString()] = {
        name: profile.name,
        avatar: profile.avatar
      };
    });
    
    // Create leaderboard entries with names and ranks
    const leaderboard = topUsers.map((user, index) => ({
      id: user.userId.toString(),
      position: index + 1,
      name: profileMap[user.userId.toString()] ? profileMap[user.userId.toString()].name : 'Anonymous User',
      avatar: profileMap[user.userId.toString()] ? profileMap[user.userId.toString()].avatar : null,
      level: user.level.current,
      points: user.points.total,
      badges: user.badges.length,
      streak: user.streaks.current
    }));
    
    // Find current user's rank
    const userId = req.user._id;
    const userGamification = await Gamification.findOne({ userId }).lean();
    
    let userRank = null;
    if (userGamification) {
      // Count users with more points than current user
      const higherRankedCount = await Gamification.countDocuments({
        $or: [
          { 'points.total': { $gt: userGamification.points.total } },
          { 
            'points.total': userGamification.points.total,
            'streaks.current': { $gt: userGamification.streaks.current }
          }
        ]
      });
      
      userRank = higherRankedCount + 1;
    }
    
    res.json({ 
      success: true, 
      leaderboard,
      userRank
    });
  } catch (error) {
    console.error('Error fetching leaderboard:', error);
    res.status(500).json({ success: false, error: 'Server error' });
  }
});

// Helper functions
function calculateNextLevelPoints(currentLevel) {
  // Formula: base points × (level multiplier)²
  const basePoints = 100;
  const nextLevel = currentLevel + 1;
  return Math.floor(basePoints * Math.pow(nextLevel, 2));
}

function calculateProgressPercentage(currentPoints, currentLevel) {
  const nextLevelPoints = calculateNextLevelPoints(currentLevel);
  const currentLevelPoints = calculateNextLevelPoints(currentLevel - 1);
  const pointsNeeded = nextLevelPoints - currentLevelPoints;
  const pointsAchieved = Math.max(0, currentPoints - currentLevelPoints);
  
  // Calculate percentage, ensuring it stays between 0-100
  const percentage = Math.min(100, Math.max(0, Math.floor((pointsAchieved / pointsNeeded) * 100)));
  
  return percentage;
}

// Helper function to determine badge type based on reward points
function determineBadgeType(points) {
  if (!points) return 'bronze';
  
  if (points >= 1000) return 'legendary';
  if (points >= 750) return 'master';
  if (points >= 500) return 'diamond';
  if (points >= 300) return 'platinum';
  if (points >= 200) return 'gold';
  if (points >= 100) return 'silver';
  return 'bronze';
}

module.exports = router;
