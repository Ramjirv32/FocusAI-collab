const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Gamification = require('../models/Gamification');
const UserProfile = require('../models/UserProfile');
const ProductivitySummary = require('../models/ProductivitySummary');

// Get user gamification stats
router.get('/stats', auth, async (req, res) => {
  try {
    const gamification = await Gamification.findOne({ userId: req.user._id });
    
    if (!gamification) {
      return res.status(404).json({ error: 'Gamification data not found' });
    }

    // Calculate points needed for next level
    const currentLevel = gamification.level.current;
    const nextLevelPoints = Math.floor(1000 * Math.pow(1.5, currentLevel));
    const currentLevelPoints = Math.floor(1000 * Math.pow(1.5, currentLevel - 1));
    const pointsToNextLevel = nextLevelPoints - gamification.points.total;
    const totalPointsForLevel = nextLevelPoints - currentLevelPoints;

    // Count badges by rarity
    const badgeCounts = {
      bronze: 0,
      silver: 0,
      gold: 0,
      platinum: 0,
      diamond: 0,
      master: 0,
      legendary: 0
    };

    gamification.badges.forEach(badge => {
      // Map rarity to frontend badge type
      let type = 'bronze';
      switch(badge.rarity?.toLowerCase()) {
        case 'common': type = 'bronze'; break;
        case 'rare': type = 'silver'; break;
        case 'epic': type = 'gold'; break;
        case 'legendary': type = 'platinum'; break;
        case 'mythic': type = 'diamond'; break;
        case 'ultimate': type = 'master'; break;
      }
      
      if (badgeCounts.hasOwnProperty(type)) {
        badgeCounts[type]++;
      }
    });

    // Create stats response
    const stats = {
      level: gamification.level.current,
      points: gamification.points.total,
      pointsToNextLevel,
      totalPointsForLevel,
      achievements: {
        total: 20, // Adjust based on your total achievements
        completed: gamification.badges.length
      },
      challenges: {
        total: gamification.challenges.length,
        completed: gamification.challenges.filter(c => c.completed).length,
        active: gamification.challenges.filter(c => !c.completed).length
      },
      streak: {
        current: gamification.streaks?.current || 0,
        longest: gamification.streaks?.longest || 0
      },
      badges: badgeCounts
    };

    res.json(stats);
  } catch (error) {
    console.error('Error fetching gamification stats:', error);
    res.status(500).json({ error: 'Failed to fetch gamification stats' });
  }
});

// Get achievements
router.get('/achievements', auth, async (req, res) => {
  try {
    const gamification = await Gamification.findOne({ userId: req.user._id });
    
    if (!gamification) {
      return res.status(404).json({ error: 'Gamification data not found' });
    }

    // Define badge definitions (you can move this to a separate file)
    const BADGES = {
      'focus-master': {
        name: 'Focus Master',
        description: 'Achieve 85%+ focus score for 5 consecutive days',
        icon: 'Target',
        rarity: 'epic',
        category: 'focus',
        points: 500
      },
      'consistency-champion': {
        name: 'Consistency Champion',
        description: 'Maintain a 7-day productivity streak',
        icon: 'Flame',
        rarity: 'rare',
        category: 'streak',
        points: 300
      },
      'productivity-wizard': {
        name: 'Productivity Wizard',
        description: 'Complete 40 hours of productive work',
        icon: 'TrendingUp',
        rarity: 'legendary',
        category: 'productivity',
        points: 1000
      },
      'early-bird': {
        name: 'Early Bird',
        description: 'Start productive sessions before 8 AM for 5 days',
        icon: 'Clock',
        rarity: 'common',
        category: 'time',
        points: 150
      },
      'night-owl': {
        name: 'Night Owl',
        description: 'Complete productive sessions after 10 PM for 3 days',
        icon: 'Clock',
        rarity: 'common',
        category: 'time',
        points: 150
      },
      'distraction-slayer': {
        name: 'Distraction Slayer',
        description: 'Avoid distractions for 3 consecutive hours',
        icon: 'Zap',
        rarity: 'rare',
        category: 'focus',
        points: 250
      }
    };

    // Get user's earned badges
    const earnedBadgeIds = new Set(gamification.badges.map(badge => badge.badgeId));
    
    // Map all badges (both earned and not yet earned)
    const achievements = Object.entries(BADGES).map(([id, badgeInfo]) => {
      const earnedBadge = gamification.badges.find(b => b.badgeId === id);
      
      // Map rarity to frontend badge type
      let badgeType = 'bronze';
      switch(badgeInfo.rarity.toLowerCase()) {
        case 'common': badgeType = 'bronze'; break;
        case 'rare': badgeType = 'silver'; break;
        case 'epic': badgeType = 'gold'; break;
        case 'legendary': badgeType = 'platinum'; break;
        case 'mythic': badgeType = 'diamond'; break;
        case 'ultimate': badgeType = 'master'; break;
      }
      
      // Calculate progress (simplified version)
      let progress = 0;
      if (earnedBadgeIds.has(id)) {
        progress = 100;
      } else {
        // Estimate progress based on the badge category
        switch(badgeInfo.category) {
          case 'focus':
            progress = Math.min(100, Math.round((gamification.statistics?.averageFocusScore || 0) * 1.2));
            break;
          case 'streak':
            progress = Math.min(100, Math.round((gamification.streaks?.current || 0) / 7 * 100));
            break;
          case 'productivity':
            progress = Math.min(100, Math.round((gamification.statistics?.totalProductiveTime || 0) / 2400 * 100));
            break;
          case 'time':
            progress = Math.min(100, Math.round(20 + Math.random() * 30)); // Random progress for time-based achievements
            break;
          default:
            progress = Math.min(100, Math.round(10 + Math.random() * 40));
        }
      }
      
      return {
        id,
        name: badgeInfo.name,
        description: badgeInfo.description,
        icon: badgeInfo.icon,
        type: badgeType,
        progress,
        target: 100,
        completed: earnedBadgeIds.has(id),
        completedAt: earnedBadge ? earnedBadge.earnedDate : undefined,
        pointsAwarded: badgeInfo.points,
        category: badgeInfo.category,
        claimed: earnedBadge ? true : false
      };
    });

    res.json(achievements);
  } catch (error) {
    console.error('Error fetching achievements:', error);
    res.status(500).json({ error: 'Failed to fetch achievements' });
  }
});

// Get challenges
router.get('/challenges', auth, async (req, res) => {
  try {
    const gamification = await Gamification.findOne({ userId: req.user._id });
    
    if (!gamification) {
      return res.status(404).json({ error: 'Gamification data not found' });
    }

    // Helper function to get icon based on challenge category
    const getChallengeIcon = (category) => {
      switch(category) {
        case 'daily': return 'Calendar';
        case 'weekly': return 'Calendar';
        case 'focus': return 'Target';
        case 'productivity': return 'TrendingUp';
        case 'time': return 'Clock';
        case 'streak': return 'Flame';
        case 'distraction': return 'Zap';
        default: return 'Award';
      }
    };
    
    // Helper function to get badge type based on challenge category
    const getChallengeBadgeType = (category) => {
      switch(category) {
        case 'daily': return 'bronze';
        case 'focus': return 'silver';
        case 'productivity': return 'gold';
        case 'time': return 'bronze';
        case 'streak': return 'silver';
        case 'distraction': return 'platinum';
        default: return 'bronze';
      }
    };

    // Ensure each challenge has a challengeId
    const challenges = gamification.challenges.map((challenge, index) => {
      return {
        id: challenge.challengeId || `c${index + 1}`,
        name: challenge.name,
        description: challenge.description,
        icon: getChallengeIcon(challenge.category),
        type: getChallengeBadgeType(challenge.category),
        progress: challenge.progress,
        target: challenge.target,
        completed: challenge.completed,
        deadline: challenge.expiryDate,
        completedAt: challenge.completed ? challenge.claimedDate : undefined,
        pointsAwarded: challenge.reward,
        category: challenge.category,
        isActive: true // Assume all challenges are active for now
      };
    });

    res.json(challenges);
  } catch (error) {
    console.error('Error fetching challenges:', error);
    res.status(500).json({ error: 'Failed to fetch challenges' });
  }
});

// Get leaderboard
router.get('/leaderboard', auth, async (req, res) => {
  try {
    const { limit = 10, timeFrame = 'total' } = req.query;
    
    let sortField;
    switch (timeFrame) {
      case 'daily':
        sortField = { 'points.daily': -1 };
        break;
      case 'weekly':
        sortField = { 'points.weekly': -1 };
        break;
      case 'monthly':
        sortField = { 'points.monthly': -1 };
        break;
      default:
        sortField = { 'points.total': -1 };
    }

    // Get gamification data with user profiles
    const leaderboardData = await Gamification.aggregate([
      {
        $lookup: {
          from: 'userprofiles',
          localField: 'userId',
          foreignField: 'userId',
          as: 'profile'
        }
      },
      {
        $sort: sortField
      },
      {
        $limit: parseInt(limit)
      },
      {
        $project: {
          userId: 1,
          email: 1,
          points: 1,
          level: 1,
          streaks: 1,
          'profile.displayName': 1,
          'profile.profilePhoto': 1
        }
      }
    ]);
    
    // Format the leaderboard response to match frontend expectations
    const leaderboard = leaderboardData.map((entry, index) => {
      const profile = entry.profile[0] || {};
      return {
        id: entry.userId.toString(),
        name: profile.displayName || entry.email.split('@')[0],
        avatar: profile.profilePhoto || `https://api.dicebear.com/6.x/avataaars/svg?seed=${entry.email}`,
        points: entry.points.total,
        level: entry.level.current,
        position: index + 1,
        streak: entry.streaks?.current || 0
      };
    });

    res.json(leaderboard);
  } catch (error) {
    console.error('Error fetching leaderboard:', error);
    res.status(500).json({ error: 'Failed to fetch leaderboard' });
  }
});

// Claim achievement reward
router.post('/achievements/:id/claim', auth, async (req, res) => {
  try {
    const achievementId = req.params.id;
    const gamification = await Gamification.findOne({ userId: req.user._id });
    
    if (!gamification) {
      return res.status(404).json({ error: 'Gamification data not found' });
    }

    const badge = gamification.badges.find(b => b.badgeId === achievementId);
    if (!badge) {
      return res.status(404).json({ error: 'Achievement not found or not earned yet' });
    }

    // Add points to user's score
    // You need to define BADGES in your controller with points values
    const BADGES = {
      'focus-master': { points: 500 },
      'consistency-champion': { points: 300 },
      'productivity-wizard': { points: 1000 },
      'early-bird': { points: 150 },
      'night-owl': { points: 150 },
      'distraction-slayer': { points: 250 }
    };

    const pointsAwarded = BADGES[achievementId]?.points || 100;
    gamification.points.total += pointsAwarded;
    
    await gamification.save();

    res.json({
      success: true,
      pointsAwarded,
      totalPoints: gamification.points.total
    });
  } catch (error) {
    console.error('Error claiming achievement:', error);
    res.status(500).json({ error: 'Failed to claim achievement' });
  }
});

// Join challenge
router.post('/challenges/:id/join', auth, async (req, res) => {
  try {
    const challengeId = req.params.id;
    const gamification = await Gamification.findOne({ userId: req.user._id });
    
    if (!gamification) {
      return res.status(404).json({ error: 'Gamification data not found' });
    }

    const challenge = gamification.challenges.find(c => c.challengeId === challengeId);
    if (!challenge) {
      return res.status(404).json({ error: 'Challenge not found' });
    }

    // Mark the challenge as active
    challenge.isActive = true;
    
    await gamification.save();

    res.json({
      success: true,
      challenge
    });
  } catch (error) {
    console.error('Error joining challenge:', error);
    res.status(500).json({ error: 'Failed to join challenge' });
  }
});

module.exports = router;
