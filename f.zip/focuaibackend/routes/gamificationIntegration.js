const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Gamification = require('../models/Gamification');
const ProductivitySummary = require('../models/ProductivitySummary');
const FocusSession = require('../models/FocusSession');

/**
 * Update gamification based on productivity data
 * This endpoint syncs user's productivity and focus data with their gamification profile
 */
router.post('/sync-productivity', auth, async (req, res) => {
  try {
    // Get user's gamification data
    let gamification = await Gamification.findOne({ userId: req.user._id });
    
    if (!gamification) {
      // Create new gamification profile if it doesn't exist
      gamification = new Gamification({
        userId: req.user._id,
        email: req.user.email,
      });
    }

    // Get today's date in YYYY-MM-DD format
    const today = new Date().toISOString().split('T')[0];
    
    // Get recent productivity data (last 7 days)
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
    const dateString = sevenDaysAgo.toISOString().split('T')[0];
    
    const productivityData = await ProductivitySummary.find({
      userId: req.user._id,
      date: { $gte: dateString }
    }).sort({ date: -1 });
    
    // Get recent focus sessions
    const focusSessions = await FocusSession.find({
      userId: req.user._id,
      createdAt: { $gte: sevenDaysAgo }
    }).sort({ createdAt: -1 });

    // Calculate stats from productivity data
    let totalFocusScore = 0;
    let totalProductiveTime = 0;
    let totalNonProductiveTime = 0;
    let daysWithActivity = 0;
    
    // Check if user was active today
    let activeToday = false;
    
    productivityData.forEach(day => {
      totalFocusScore += day.focusScore || 0;
      totalProductiveTime += day.totalProductiveTime || 0;
      totalNonProductiveTime += day.totalNonProductiveTime || 0;
      
      if (day.overallTotalUsage > 0) {
        daysWithActivity++;
      }
      
      if (day.date === today && day.overallTotalUsage > 0) {
        activeToday = true;
      }
    });
    
    const averageFocusScore = productivityData.length > 0 
      ? totalFocusScore / productivityData.length 
      : 0;
    
    // Update streak
    if (activeToday) {
      // Increment streak if active today
      gamification.streaks.current += 1;
      
      // Update longest streak if current is longer
      if (gamification.streaks.current > gamification.streaks.longest) {
        gamification.streaks.longest = gamification.streaks.current;
      }
      
      gamification.streaks.lastActiveDate = new Date();
    } else {
      // Check if streak should be reset (inactive for more than a day)
      const lastActiveDate = gamification.streaks.lastActiveDate || new Date(0);
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      
      if (lastActiveDate < yesterday) {
        gamification.streaks.current = 0;
      }
    }
    
    // Update statistics
    gamification.statistics.totalProductiveTime = Math.max(
      gamification.statistics.totalProductiveTime || 0,
      totalProductiveTime
    );
    
    gamification.statistics.totalDistractionTime = Math.max(
      gamification.statistics.totalDistractionTime || 0,
      totalNonProductiveTime
    );
    
    gamification.statistics.averageFocusScore = averageFocusScore;
    
    // Calculate focus sessions stats
    if (focusSessions.length > 0) {
      let totalFocusTime = 0;
      let totalSessions = focusSessions.length;
      let highestFocusScore = 0;
      
      focusSessions.forEach(session => {
        totalFocusTime += session.duration || 0;
        
        if ((session.focusScore || 0) > highestFocusScore) {
          highestFocusScore = session.focusScore;
        }
      });
      
      gamification.statistics.totalFocusTime = Math.max(
        gamification.statistics.totalFocusTime || 0,
        totalFocusTime
      );
      
      gamification.statistics.sessionsCompleted = Math.max(
        gamification.statistics.sessionsCompleted || 0,
        totalSessions
      );
      
      gamification.statistics.bestFocusScore = Math.max(
        gamification.statistics.bestFocusScore || 0,
        highestFocusScore
      );
    }

    // Award points based on productivity
    const productiveHours = totalProductiveTime / 60; // Convert minutes to hours
    const distractionHours = totalNonProductiveTime / 60;
    
    // Base points for productive time (10 points per hour)
    const productivePoints = Math.floor(productiveHours * 10);
    
    // Bonus points for high focus score
    let focusBonus = 0;
    if (averageFocusScore >= 90) focusBonus = 50;
    else if (averageFocusScore >= 80) focusBonus = 30;
    else if (averageFocusScore >= 70) focusBonus = 15;
    
    // Penalty for too much distraction (but never negative)
    const distractionPenalty = Math.min(
      productivePoints * 0.1,
      Math.floor(distractionHours * 5)
    );
    
    // Calculate total points earned
    const pointsEarned = Math.max(0, productivePoints + focusBonus - distractionPenalty);
    
    // Update user's points
    gamification.points.total += pointsEarned;
    gamification.points.daily += pointsEarned;
    gamification.points.weekly += pointsEarned;
    gamification.points.monthly += pointsEarned;
    
    // Check and update challenges progress
    updateChallenges(gamification, {
      productiveHours,
      distractionHours,
      focusScore: averageFocusScore,
      streak: gamification.streaks.current
    });
    
    // Check for new badges
    const newBadges = checkForBadges(gamification);
    
    // Add new badges if earned
    if (newBadges.length > 0) {
      newBadges.forEach(badge => {
        gamification.badges.push({
          badgeId: badge.id,
          name: badge.name,
          description: badge.description,
          icon: badge.icon,
          rarity: badge.rarity,
          category: badge.category,
          earnedDate: new Date()
        });
        
        // Award bonus points for badges
        gamification.points.total += badge.points;
      });
    }
    
    // Update level based on total points
    const newLevel = calculateLevel(gamification.points.total);
    if (newLevel > gamification.level.current) {
      gamification.level.current = newLevel;
    }
    
    // Save updated gamification data
    await gamification.save();
    
    // Return updated gamification data
    res.json({
      success: true,
      gamification,
      pointsEarned,
      newBadges
    });
  } catch (error) {
    console.error('Error syncing productivity data:', error);
    res.status(500).json({ error: 'Failed to sync productivity data' });
  }
});

// Helper function to calculate level based on points
function calculateLevel(points) {
  return Math.floor(Math.log(points / 1000 + 1) / Math.log(1.5)) + 1;
}

// Helper function to update challenges progress
function updateChallenges(gamification, stats) {
  // Update daily challenges
  gamification.challenges.forEach(challenge => {
    // Skip already completed challenges
    if (challenge.completed) return;
    
    // Update progress based on challenge type
    switch (challenge.challengeId) {
      case 'daily-focus':
        // Daily focus score goal
        challenge.progress = stats.focusScore;
        if (challenge.progress >= challenge.target) {
          challenge.completed = true;
          challenge.completedAt = new Date();
        }
        break;
        
      case 'daily-productive':
        // Daily productive hours
        challenge.progress = stats.productiveHours * 60; // Convert to minutes
        if (challenge.progress >= challenge.target) {
          challenge.completed = true;
          challenge.completedAt = new Date();
        }
        break;
        
      case 'daily-distraction':
        // Keep distractions under target
        if (stats.distractionHours * 60 <= challenge.target) {
          challenge.progress = challenge.target;
          challenge.completed = true;
          challenge.completedAt = new Date();
        }
        break;
        
      case 'weekly-streak':
        // Weekly streak challenge
        challenge.progress = stats.streak;
        if (challenge.progress >= challenge.target) {
          challenge.completed = true;
          challenge.completedAt = new Date();
        }
        break;
    }
  });
}

// Helper function to check for badges
function checkForBadges(gamification) {
  const earnedBadgeIds = new Set(gamification.badges.map(b => b.badgeId));
  const newBadges = [];
  
  // Define badge criteria
  const badgeDefinitions = {
    'focus-master': {
      id: 'focus-master',
      name: 'Focus Master',
      description: 'Achieve 85%+ focus score for 5 consecutive days',
      icon: 'Target',
      rarity: 'epic',
      category: 'focus',
      points: 500,
      condition: () => gamification.statistics.averageFocusScore >= 85
    },
    'consistency-champion': {
      id: 'consistency-champion',
      name: 'Consistency Champion',
      description: 'Maintain a 7-day productivity streak',
      icon: 'Flame',
      rarity: 'rare',
      category: 'streak',
      points: 300,
      condition: () => gamification.streaks.current >= 7
    },
    'productivity-wizard': {
      id: 'productivity-wizard',
      name: 'Productivity Wizard',
      description: 'Complete 40 hours of productive work',
      icon: 'TrendingUp',
      rarity: 'legendary',
      category: 'productivity',
      points: 1000,
      condition: () => gamification.statistics.totalProductiveTime >= 2400 // 40 hours in minutes
    },
    'distraction-slayer': {
      id: 'distraction-slayer',
      name: 'Distraction Slayer',
      description: 'Avoid distractions for 3 consecutive hours',
      icon: 'Zap',
      rarity: 'rare',
      category: 'focus',
      points: 250,
      condition: () => {
        // This is a simplified condition; you'd need more data for a real implementation
        return gamification.statistics.totalDistractionTime < gamification.statistics.totalProductiveTime * 0.2;
      }
    },
    'perfectionist': {
      id: 'perfectionist',
      name: 'Perfectionist',
      description: 'Achieve 100% focus score in a session',
      icon: 'Award',
      rarity: 'legendary',
      category: 'focus',
      points: 750,
      condition: () => gamification.statistics.bestFocusScore >= 100
    }
  };
  
  // Check each badge
  Object.values(badgeDefinitions).forEach(badge => {
    // Skip if already earned
    if (earnedBadgeIds.has(badge.id)) return;
    
    // Check if condition is met
    if (badge.condition()) {
      newBadges.push(badge);
    }
  });
  
  return newBadges;
}

module.exports = router;
