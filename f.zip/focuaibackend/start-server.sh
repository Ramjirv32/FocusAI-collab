

echo "Starting FocusAI backend server..."
cd "$(dirname "$0")" # Navigate to script directory
node server.js
