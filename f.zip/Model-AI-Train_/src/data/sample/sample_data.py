"""Sample data for testing and development"""

REAL_MONGODB_DATA = [
    {"userId": "6872a2289ac6b2159f22084d", "email": "s@gmail.com", "date": "2025-07-12", "appName": "focusai-app", "duration": 275, "lastUpdated": "2025-07-12T18:33:51.141Z"},
    {"userId": "6872a2289ac6b2159f22084d", "email": "s@gmail.com", "date": "2025-07-12", "appName": "Code", "duration": 1327, "lastUpdated": "2025-07-12T18:33:16.138Z"},
    {"userId": "6872a2289ac6b2159f22084d", "email": "s@gmail.com", "date": "2025-07-12", "appName": "Google-chrome", "duration": 126, "lastUpdated": "2025-07-12T18:24:09.553Z"},
    {"userId": "6872a2289ac6b2159f22084d", "email": "s@gmail.com", "date": "2025-07-12", "appName": "Gnome-terminal", "duration": 1000, "lastUpdated": "2025-07-12T18:01:36.420Z"},
    {"userId": "6872a2289ac6b2159f22084d", "email": "s@gmail.com", "date": "2025-07-12", "appName": "Gnome-control-center", "duration": 11, "lastUpdated": "2025-07-12T18:04:27.143Z"},
    {"userId": "6872a2289ac6b2159f22084d", "email": "s@gmail.com", "date": "2025-07-12", "appName": "MongoDB Compass", "duration": 51, "lastUpdated": "2025-07-12T18:30:08.901Z"}
]