"""model_utils.py - Auto-generated file"""
