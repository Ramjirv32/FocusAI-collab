const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const gamificationSchema = new Schema({
  userId: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  email: {
    type: String,
    required: true
  },
  points: {
    total: { type: Number, default: 0 },
    daily: { type: Number, default: 0 },
    weekly: { type: Number, default: 0 },
    monthly: { type: Number, default: 0 }
  },
  level: {
    current: { type: Number, default: 1 },
    progress: { type: Number, default: 0 },
    nextLevelAt: { type: Number, default: 1000 }
  },

  badges: [{
    badgeId: String,
    name: String,
    description: String,
    icon: String,
    rarity: String,
    category: String,
    earnedDate: { type: Date, default: Date.now }
  }],

  challenges: [{
    challengeId: String,
    name: String,
    description: String,
    category: String,
    target: Number,
    progress: { type: Number, default: 0 },
    reward: Number,
    completed: { type: Boolean, default: false },
    claimed: { type: Boolean, default: false },
    claimedDate: Date,
    expiryDate: Date
  }],

  streaks: {
    current: { type: Number, default: 0 },
    longest: { type: Number, default: 0 },
    lastActiveDate: Date
  },

  statistics: {
    totalFocusTime: { type: Number, default: 0 },
    totalProductiveTime: { type: Number, default: 0 },
    totalDistractionTime: { type: Number, default: 0 },
    averageFocusScore: { type: Number, default: 0 },
    sessionsCompleted: { type: Number, default: 0 },
    lastUpdated: { type: Date, default: Date.now }
  },

  dailyReset: {
    type: Date,
    default: Date.now
  }
}, { timestamps: true });


gamificationSchema.index({ userId: 1 }, { unique: true });
gamificationSchema.index({ 'points.total': -1 });

module.exports = mongoose.model('Gamification', gamificationSchema);
